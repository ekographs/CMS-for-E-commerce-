<?php

//Include libraries
require __DIR__ . '/vendor/autoload.php';
    
//Create instance of MongoDB client
$mongoClient = (new MongoDB\Client);

//Select a database
$db = $mongoClient->gamedatabase;

//Select a collection 
$collection = $db->Products;


//Extract the data that was sent to the server

$Title = $_POST['title'];
$Code = $_POST['ID'];
$ImageURL = $_POST['IMG'];
$Price = $_POST['Pr'];
$Quantity = $_POST['SC'];
$Genre = $_POST['Gr'];
$Version = $_POST['Ver'];
$Platform = $_POST['Plat'];
$Language = $_POST['Lan'];
$Desc = $_POST['Des'];

$listTitles = json_decode($Title,true);
$listCode = json_decode($Code,true);
$listImg = json_decode($ImageURL,true);
$listPrice = json_decode($Price,true);
$listQuantity = json_decode($Quantity,true);
$listGen = json_decode($Genre,true);
$listVersion = json_decode($Version,true);
$listPlatform = json_decode($Platform,true);
$listLanguage = json_decode($Language,true);
$listDesc = json_decode($Desc,true);

//Convert to PHP array
$dataArray = [
    "Title" => $listTitles, 
    "Code" => $listCode, 
    "ImageURL" => $listImg,
    "Price" => $listPrice,
    "Quantity" => $listQuantity,
    "Genre" => $listGen,
    "Version" => $listVersion,
    "Platform" => $listPlatform,
    "Language" => $listLanguage,
    "Desc" => $listDesc
    
 ];

//Add the new product to the database
$insertResult = $collection->insertOne($dataArray);
    
//Echo result back to user
if($insertResult->getInsertedCount()==1){
    echo 'Products added.';
    echo ' New document id: ' . $insertResult->getInsertedId();
}
else {
    echo 'Error adding products';
}







