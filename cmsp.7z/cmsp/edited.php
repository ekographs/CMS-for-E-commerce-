<html>
<head>
    <title> List Product</title>
    <link href="ms.css" rel="stylesheet">
</head>

<body>

    <div id="wrapper">
        <div id="header">
                <div id="subheader">
        <div class="container">  
                    <p>Product Edited succefully</p>
                </div>    
                </div> 
        <div id="cm">
            <h2>CMS</h2>
        </div>
        <div id="cont">
            <mng>
                <a href="cmshome.php">Home</a>
                <a href="AddProducts.php">Add Products</a>
                <a href="ListProducts.php">List Products</a>
                <a href="EditProducts.php">Edit Products</a>
                <a href="DeleteProducts.php">Delete Products</a>
                <a href="ViewOrders.php">View Orders</a>
                <a href="DeleteOrders.php">Delete Orders</a>
        </mng>
        </div> 
        </div>
    </div>

<?php

//Include libraries
require __DIR__ . '/vendor/autoload.php';
    
//Create instance of MongoDB client
$mongoClient = (new MongoDB\Client);

//Select a database
$db = $mongoClient->gamedatabase;

//Select a collection 
//$collection = $db->Products;
//Extract the customer details 
$Title= filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING);
$Code = filter_input(INPUT_POST, 'ID', FILTER_SANITIZE_STRING);
$ImageURL = filter_input(INPUT_POST, 'IMG', FILTER_SANITIZE_STRING);
$Price = filter_input(INPUT_POST, 'Pr', FILTER_SANITIZE_STRING);
$Quantity = filter_input(INPUT_POST, 'SC', FILTER_SANITIZE_STRING);
$Genre = filter_input(INPUT_POST, 'Gr', FILTER_SANITIZE_STRING);
$Version = filter_input(INPUT_POST, 'Ver', FILTER_SANITIZE_STRING);
$Platform = filter_input(INPUT_POST, 'Plat', FILTER_SANITIZE_STRING);
$Language = filter_input(INPUT_POST, 'Lan', FILTER_SANITIZE_STRING);
$Desc = filter_input(INPUT_POST, 'Des', FILTER_SANITIZE_STRING);


//Criteria for finding document to replace
$replaceCriteria = [
       "Title" => $Title 
];

//Data to replace
$ProductsData = [
    "Title" => $Title,
    "Code" => $Code, 
    "ImageURL" => $ImageURL,
    "Price" => $Price,
    "Quantity" => $Quantity,
    "Genre" =>$Genre ,
    "Version" => $Version ,
    "Platform" => $Platform ,
    "Language" => $Language,
    "Desc" => $Desc
 ];
//Replace customer data for this ID
$updateRes = $db->Products->replaceOne($replaceCriteria, $ProductsData);
    
//Echo result back to user
if($updateRes->getModifiedCount() == 1)
    echo 'Customer document successfully replaced.';
else
    echo 'Customer replacement error.';

?>

</body>
</html>
