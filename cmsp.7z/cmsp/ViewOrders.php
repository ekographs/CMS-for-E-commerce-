<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

 if(!isset($_SESSION['LoggedInUser']) || empty($_SESSION['LoggedInUser'])) {
    header('Location: cmshome.php?cms=1');
 }
 

//Include libraries
require __DIR__ . '/vendor/autoload.php';
    
//Create instance of MongoDB client
$mongoClient = (new MongoDB\Client);

//Select a database
$db = $mongoClient->gamedatabase;

//Select a collection 
//$collection = $db->cmsarea;

$mObj = $db->order->find();
?>
<html>
<head>
    <title> View Orders</title>
    <link href="ms.css" rel="stylesheet">
</head>

<body>

    <div id="wrapper">
        <div id="header">
                <div id="subheader">
        <div class="container">  
                    <p>Welcome, Here Is The List Of Orders</p>
                </div>    
                </div> 
        <div id="cm">
            <h2>CMS</h2>
        </div>
        <div id="cont">
            <mng>
                <a href="cmshome.php">Home</a>
                <a href="AddProducts.php">Add Products</a>
                <a href="ListProducts.php">List Products</a>
                <a href="EditProducts.php">Edit Products</a>
                <a href="DeleteProducts.php">Delete Products</a>
                <a href="ViewOrders.php">View Orders</a>
                <a href="DeleteOrders.php">Delete Orders</a>
        </mng>
        </div> 
        </div>
    </div>



    <div class="Lop">
    <table style="width:80%">
      <caption>Orders</caption>
      <tr>
        <th>OrderID</th>
        <th>ProductID</th>
        <th>PhoneNumber</th>
        <th>Date</th>
        <th>ClientName</th>
        <th>Quantity</th>
        <th>Adress</th>
        <th>TotalPrice</th>

      </tr>
      <?php 
      foreach($mObj as $row){
        $products = '<ul>';
        $quantities = '<ul>';
        foreach($row['Products'] as $product){
          $products .= '<li>'.$product['ProductID'].'</li>';
          $quantities .= '<li>'.$product['Quantity'].'</li>';
        }
        $products .= '</ul>';
        $quantities .= '</ul>';
        ?>
        <tr>
          <td><?php echo $row['OrderID'] ?></td>
          <td><?php echo $products ?></td>
          <td><?php echo $row['PhoneNumber'] ?></td>
          <td><?php echo $row['Date'] ?></td>
          <td><?php echo $row['ClientName'] ?></td>
          <td><?php echo $quantities ?></td>
          <td><?php echo $row['Adress'] ?></td>
          <td><?php echo $row['TotalPrice'] ?></td>
          
        </tr>
<?php
         }
      ?>
    </table>
</div>

</body>

</html>