<?php
//Include libraries
require __DIR__ . '/vendor/autoload.php';
    
//Create instance of MongoDB client
$mongoClient = (new MongoDB\Client);

//Select a database
$db = $mongoClient->gamedatabase;


//Extract the data that was sent to the server
$Title = filter_input(INPUT_GET, 'Title', FILTER_SANITIZE_STRING);

//Create a PHP array with our search criteria
$findCriteria = [
    "Title" =>  $Title,
 ];


//Find all of the customers that match  this criteria
$cursor = $db->Products->find([ '$text' => [ '$search' => $Title ]] );

//Output the results
echo "<h1>Results</h1>";
foreach ($cursor as $cust){
   echo "<p>";
   echo "Title: " . $cust['Title'].'<br></br>';
   echo '<img src= '. $cust['ImageURL']. ">'<br></br>'";
   echo " Price: " . $cust['Price'].'<br></br>';
   echo " Quantity: " . $cust['Quantity'].'<br></br>';
   echo " Genre: " . $cust['Genre'].'<br></br>';
   echo " Version: " . $cust['Version'].'<br></br>';
   echo " Platform: " . $cust['Platform'].'<br></br>';
   echo " Language: " . $cust['Language'].'<br></br>';
   echo "</p>";
}
?>