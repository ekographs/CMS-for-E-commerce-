<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

 if(!isset($_SESSION['LoggedInUser']) || empty($_SESSION['LoggedInUser'])) {
    header('Location: cmshome.php?cms=1');
 }
 
//Include libraries
require __DIR__ . '/vendor/autoload.php';
    
//Create instance of MongoDB client
$mongoClient = (new MongoDB\Client);

//Select a database
$db = $mongoClient->gamedatabase;

//Select a collection 
//$collection = $db->cmsarea;

$mObj = $db->Products->find();
?>
<html>
<head>
    <title> List Product</title>
    <link href="ms.css" rel="stylesheet">
</head>

<body>

    <div id="wrapper">
        <div id="header">
                <div id="subheader">
        <div class="container">  
                    <p>Welcome, Here Is The List Of Products</p>
                </div>    
                </div> 
        <div id="cm">
            <h2>CMS</h2>
        </div>
        <div id="cont">
            <mng>
                <a href="cmshome.php">Home</a>
                <a href="AddProducts.php">Add Products</a>
                <a href="ListProducts.php">List Products</a>
                <a href="EditProducts.php">Edit Products</a>
                <a href="DeleteProducts.php">Delete Products</a>
                <a href="ViewOrders.php">View Orders</a>
                <a href="DeleteOrders.php">Delete Orders</a>
        </mng>
        </div> 
        </div>
    </div>



    <div class="Lop">
    <table style="width:100%">
      <caption>Products</caption>
      <tr>
        <th>Title</th>
        <th>Code</th>
        <th>Image</th>
        <th>Price</th>
        <th>Genre</th>
        <th>Version</th>
        <th>Platform</th>
        <th>Language</th>
        <th>Quantity</th>
        <th>ID</th>
        <th>Desc</th>
      </tr>
      
      <?php 
      foreach($mObj as $row){
        ?>
        <tr>
          <td><?php echo $row['Title'] ?></td>
          <td><?php echo $row['Code'] ?></td>
          <td><?php echo $row['ImageURL'] ?></td>
          <td><?php echo $row['Price'] ?></td>
          <td><?php echo $row['Genre'] ?></td>
          <td><?php echo $row['Version'] ?></td>
          <td><?php echo $row['Platform'] ?></td>
          <td><?php echo $row['Language'] ?></td>
          <td><?php echo $row['Quantity'] ?></td>
          <td><?php echo $row['_id'] ?></td>
          <td><?php echo $row['Desc'] ?></td>
          
        </tr>
      <?php
         }
      ?>
    </table>
</div>

</body>

</html>