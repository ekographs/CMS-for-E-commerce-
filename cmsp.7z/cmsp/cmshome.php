<?php

//Include libraries
require __DIR__ . '/vendor/autoload.php';
    
//Create instance of MongoDB client
$mongoClient = (new MongoDB\Client);

//Select a database
$db = $mongoClient->gamedatabase;

//Select a collection 
$collection = $db->admin;

$mObj =$collection->findOne(["username" => 'emma' ]);


$error=false;

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if ($_POST){ 
    $username=$_POST['username'];
    $password=$_POST['password'];
    $mObj =$collection->findOne(["username" => $username]);

    if ($mObj != NULL){
        if($mObj['password'] == $password){
            // Set session variables
        $_SESSION["LoggedInUser"] = $username;
        }
        else {
            $error="Incorrect Password";
        }
    } else{
        $error="No user found";
    }
   
} 

?>

<html>
    <head>
     <title>::Cms Home::</title> 
     <link href="ms.css" rel="stylesheet">
    </head>
<body>
       <div id="wrapper">
        <div id="header">
                <div id="subheader">
        <div class="container">  
                    <p>Welcome, Login To Manage Products</p>
                </div>    
                </div> 
        <div id="cm">
            <h2>CMS</h2>
        </div>
        <div id="cont">
            <mng>
                <a href="cmshome.php">Home</a>
                <a href="AddProducts.php">Add Products</a>
                <a href="ListProducts.php">List Products</a>
                <a href="EditProducts.php">Edit Products</a>
                <a href="DeleteProducts.php">Delete Products</a>
                <a href="ViewOrders.php">View Orders</a>
                <a href="DeleteOrders.php">Delete Orders</a>
        </mng>
        </div>  
        <?php 
        if(isset($_SESSION['LoggedInUser']) && !empty($_SESSION['LoggedInUser'])) {
   echo '<br><br><p style="text-align:center">Welcome '.$_SESSION['LoggedInUser']. ' <a href="logout.php">Logout</a></p>';
}
else {?>

    <form class="oxb" action="cmshome.php" method="post">
        <?php if(isset($_GET['cms'])){ ?>
                <p style="color: wheat">Login to access CMS</p>
        <?php } ?>
            <h1>Login</h1>
            <input type="user" name="username" placeholder="Username"required>
            <input type="password" name="password" placeholder="Password"required>
            <input type="Submit" name="log" value="Login">
            <?php 
            if($error){ ?>
                    <p style="color: red"><?= $error ?></p>
          <?php  } ?>
        </form> 
<?php
}?>  
         
    </body>
</html>