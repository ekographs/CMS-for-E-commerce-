<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

 if(!isset($_SESSION['LoggedInUser']) || empty($_SESSION['LoggedInUser'])) {
    header('Location: cmshome.php?cms=1');
 }
 ?>
<html>
<head>
    <title> Edit Product</title>
    <link href="ms.css" rel="stylesheet">
</head>

<body>

    <div id="wrapper">
        <div id="header">
                <div id="subheader">
        <div class="container">  
                    <p>Select The Product You Want To Edit</p>
                </div>    
                </div> 
        <div id="cm">
            <h2>CMS</h2>
        </div>
        <div id="cont">
            <mng>
                <a href="cmshome.php">Home</a>
                <a href="AddProducts.php">Add Products</a>
                <a href="ListProducts.php">List Products</a>
                <a href="EditProducts.php">Edit Products</a>
                <a href="DeleteProducts.php">Delete Products</a>
                <a href="ViewOrders.php">View Orders</a>
                <a href="DeleteOrders.php">Delete Orders</a>
        </mng>
        </div> 
   
        <!--Edit item area--> 
         <div class="ggt">
            <div id="find">
                <form action="edited.php" method="post">
                   <!-- <input  type="text" name="id" id="ID" placeholder="Enter Product ID"> -->
                    
                    Title:<br>
                <input type="text" name="title" id="title" required value=""><br>
                Code:<br>
                <input type="text" name="ID" id="ID" required value=""><br>
                ImageURL:<br>
                <input type="text" name="IMG" id="IMG" required value=""><br>
                Price:<br>
                <input type="text" name="Pr" id="Pr" required  value=""><br>
                Version:<br>
                <input type="text" name="Ver" id="Ver" required  value=""><br>
                Platform:<br>
                <input type="text" name="Plat" id="Plat" required  value=""><br>
                Language:<br>
                <input type="text" name="Lan" id="Lan" required  value=""><br>
                Quantity:<br>
                <input type="text" name="SC" id="SC" required value=""><br>     
                Genre:<br>
                <input type="text" name="Gr" id="Gr" required value=""><br><br>
                Desc:<br>
                <input type="text" name="Des" id="Des" required value=""><br><br>
                <button type ="submit">SubmitProduct</button>
                <p id="ServerResponse"></p>
                
                </form>   
                <h1 id="ServerResponse"></h1>
               
                </div>
 
         </div>
    
</body>

  </html>