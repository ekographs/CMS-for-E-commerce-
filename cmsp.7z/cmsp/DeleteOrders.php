<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

 if(!isset($_SESSION['LoggedInUser']) || empty($_SESSION['LoggedInUser'])) {
    header('Location: cmshome.php?cms=1');
 }
 ?>
<html>
<head>
    <title> Delete Product</title>
    <link href="ms.css" rel="stylesheet">
</head>

<body>

    <div id="wrapper">
        <div id="header">
                <div id="subheader">
        <div class="container">  
                    <p>Select The Product You Want To Delete</p>
                </div>    
                </div> 
        <div id="cm">
            <h2>CMS</h2>
        </div>
        <div id="cont">
            <mng>
                <a href="cmshome.php">Home</a>
                <a href="AddProducts.php">Add Products</a>
                <a href="ListProducts.php">List Products</a>
                <a href="EditProducts.php">Edit Products</a>
                <a href="DeleteProducts.php">Delete Products</a>
                <a href="ViewOrders.php">View Orders</a>
                <a href="DeleteOrders.php">Delete Orders</a>
        </mng>
        </div> 
   
        <!--Delete item area--> 
         <div class="ord">
            <div id="odr">
                <form action="Orderdelete.php" method="post">
                    <input  type="text" name="text" placeholder="Enter Order ID" required>
                    <input  type="submit" name="oddr" value="Delete Order">
                </form>    
                </div>

         </div>
        
    
    
</body>

  </html>